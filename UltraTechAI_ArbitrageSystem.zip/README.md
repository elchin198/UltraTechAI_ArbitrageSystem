# UltraTechAI FlashLoan Arbitrage System

This project is a modular Python-based FlashLoan arbitrage system designed to execute real-time DeFi arbitrage opportunities using AI-driven strategy selection. It includes modules for opportunity detection, execution, and user management.  
> Built with Flask, SQLAlchemy, and integrated with EVM-based smart contracts.

🔒 **Security Note:** All API keys, private credentials, and real wallet addresses have been removed for privacy.  
📁 See: `arbitrage.py`, `flash_loan.py`, `opportunity.py`, `strategy.py`, `user.py`, `base.py`
