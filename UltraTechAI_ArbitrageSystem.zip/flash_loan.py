import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import joblib
import logging
from config.app_config import AppConfig

logger = logging.getLogger(__name__)

class FlashLoanDetector:
    """Flash loan detection model"""
    
    def __init__(self):
        self.config = AppConfig()
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        self.scaler = StandardScaler()
        self.is_trained = False
        self.load_model()
    
    def load_model(self):
        """Load trained model if exists"""
        try:
            self.model = joblib.load('models/flash_loan_model.joblib')
            self.scaler = joblib.load('models/flash_loan_scaler.joblib')
            self.is_trained = True
            logger.info("Flash loan model loaded successfully")
        except:
            logger.warning("No trained flash loan model found")
    
    def save_model(self):
        """Save trained model"""
        joblib.dump(self.model, 'models/flash_loan_model.joblib')
        joblib.dump(self.scaler, 'models/flash_loan_scaler.joblib')
        logger.info("Flash loan model saved successfully")
    
    def train(self, X, y):
        """Train model with new data"""
        if len(X) < self.config.MIN_SAMPLES_FOR_TRAINING:
            logger.warning(f"Not enough samples for training. Need {self.config.MIN_SAMPLES_FOR_TRAINING}, got {len(X)}")
            return False
        
        try:
            X_scaled = self.scaler.fit_transform(X)
            self.model.fit(X_scaled, y)
            self.is_trained = True
            self.save_model()
            logger.info("Flash loan model trained successfully")
            return True
        except Exception as e:
            logger.error(f"Error training flash loan model: {str(e)}")
            return False
    
    def predict(self, features):
        """Predict if transaction is a flash loan"""
        if not self.is_trained:
            raise Exception("Model not trained")
        
        try:
            X = np.array(features).reshape(1, -1)
            X_scaled = self.scaler.transform(X)
            probability = self.model.predict_proba(X_scaled)[0][1]
            prediction = probability >= 0.5
            
            return {
                'is_flash_loan': bool(prediction),
                'probability': float(probability),
                'confidence': 'high' if abs(probability - 0.5) > 0.3 else 'medium' if abs(probability - 0.5) > 0.1 else 'low'
            }
        except Exception as e:
            logger.error(f"Error predicting flash loan: {str(e)}")
            raise
    
    def status(self):
        """Get model status"""
        return {
            'trained': self.is_trained,
            'type': 'RandomForestClassifier',
            'features': [
                'gas_price',
                'gas_limit',
                'value',
                'input_length',
                'contract_interactions'
            ]
        } 