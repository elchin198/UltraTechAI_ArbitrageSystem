"""
Base models module with common utilities
"""
from datetime import datetime
from app_fixed import db

class Log(db.Model):
    """System log records"""
    id = db.Column(db.Integer, primary_key=True)
    level = db.Column(db.String(20), nullable=False)
    message = db.Column(db.Text, nullable=False)
    component = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    @classmethod
    def add_log(cls, level, message, component=None):
        """Add a new log entry"""
        log = cls(level=level, message=message, component=component)
        db.session.add(log)
        db.session.commit()
        return log
    
    @classmethod
    def get_logs(cls, limit=100, component=None, level=None):
        """Get logs with optional filtering"""
        query = cls.query
        
        if component:
            query = query.filter_by(component=component)
        
        if level:
            query = query.filter_by(level=level)
        
        return query.order_by(cls.created_at.desc()).limit(limit).all()