from dataclasses import dataclass
from typing import Optional

@dataclass
class ArbitrageOpportunity:
    """
    Model class for representing an arbitrage opportunity
    """
    network_id: int
    from_token_address: str
    to_token_address: str
    from_token_symbol: str
    to_token_symbol: str
    source_dex_name: str
    target_dex_name: str
    buy_price: float
    sell_price: float
    profit_percentage: float
    timestamp: int
    
    # Optional fields that may be set later
    status: str = "detected"  # detected, executed, failed
    transaction_hash: Optional[str] = None
    gas_used: Optional[int] = None
    gas_price: Optional[int] = None
    profit_after_gas: Optional[float] = None
    
    def __post_init__(self):
        """Validate the opportunity after initialization"""
        if self.buy_price <= 0 or self.sell_price <= 0:
            raise ValueError("Buy price and sell price must be positive")
        
        if self.from_token_symbol == self.to_token_symbol:
            raise ValueError("From token and to token must be different")
    
    def __str__(self) -> str:
        """String representation of the opportunity"""
        return (
            f"ArbitrageOpportunity: {self.from_token_symbol}/{self.to_token_symbol} "
            f"on {self.source_dex_name}->{self.target_dex_name}, "
            f"profit: {self.profit_percentage:.2f}%"
        )
    
    def is_profitable_after_gas(self, estimated_gas_cost_usd: float, min_profit_usd: float = 0.5) -> bool:
        """
        Check if the opportunity is profitable after accounting for gas costs.
        
        Args:
            estimated_gas_cost_usd: Estimated gas cost in USD
            min_profit_usd: Minimum acceptable profit in USD
            
        Returns:
            bool: True if the opportunity is profitable after gas costs
        """
        if not hasattr(self, "estimated_profit_usd"):
            return False
            
        estimated_net_profit = getattr(self, "estimated_profit_usd") - estimated_gas_cost_usd
        return estimated_net_profit >= min_profit_usd
    
    def to_dict(self):
        """Convert the opportunity to a dictionary for storage/display"""
        return {
            "network_id": self.network_id,
            "from_token": {
                "address": self.from_token_address,
                "symbol": self.from_token_symbol
            },
            "to_token": {
                "address": self.to_token_address,
                "symbol": self.to_token_symbol
            },
            "source_dex": self.source_dex_name,
            "target_dex": self.target_dex_name,
            "buy_price": self.buy_price,
            "sell_price": self.sell_price,
            "profit_percentage": self.profit_percentage,
            "timestamp": self.timestamp,
            "transaction_hash": self.transaction_hash,
            "gas_used": self.gas_used,
            "gas_price": self.gas_price,
            "status": self.status,
            "profit_after_gas": self.profit_after_gas
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create an opportunity instance from a dictionary"""
        return cls(
            network_id=data["network_id"],
            from_token_address=data["from_token"]["address"],
            to_token_address=data["to_token"]["address"],
            from_token_symbol=data["from_token"]["symbol"],
            to_token_symbol=data["to_token"]["symbol"],
            source_dex_name=data["source_dex"],
            target_dex_name=data["target_dex"],
            buy_price=data["buy_price"],
            sell_price=data["sell_price"],
            profit_percentage=data["profit_percentage"],
            timestamp=data["timestamp"],
            transaction_hash=data.get("transaction_hash"),
            gas_used=data.get("gas_used"),
            gas_price=data.get("gas_price"),
            status=data.get("status", "detected"),
            profit_after_gas=data.get("profit_after_gas")
        ) 