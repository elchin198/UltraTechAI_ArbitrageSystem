"""
Strategy models for arbitrage operations
"""
from datetime import datetime
from app_fixed import db

class Strategy(db.Model):
    """Strategy model for arbitrage operations"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    protocol = db.Column(db.String(50), nullable=False)
    min_profit = db.Column(db.Float, default=0.5)
    active = db.Column(db.Boolean, default=True)
    source_dex = db.Column(db.String(50))
    target_dex = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @classmethod
    def get_active_strategies(cls):
        """Get all active strategies"""
        return cls.query.filter_by(active=True).all()
    
    @classmethod
    def get_by_name(cls, name):
        """Find strategy by name"""
        return cls.query.filter_by(name=name).first()
    
    @classmethod
    def create_strategy(cls, name, protocol, description=None, min_profit=0.5, 
                       active=True, source_dex=None, target_dex=None):
        """Create a new strategy"""
        strategy = cls(
            name=name,
            description=description,
            protocol=protocol,
            min_profit=min_profit,
            active=active,
            source_dex=source_dex,
            target_dex=target_dex
        )
        db.session.add(strategy)
        db.session.commit()
        return strategy
    
    @classmethod
    def update_strategy(cls, strategy_id, **kwargs):
        """Update strategy attributes"""
        strategy = cls.query.get(strategy_id)
        if strategy:
            for key, value in kwargs.items():
                if hasattr(strategy, key):
                    setattr(strategy, key, value)
            
            db.session.commit()
            return strategy
        return None
    
    @classmethod
    def toggle_active(cls, strategy_id):
        """Toggle strategy active status"""
        strategy = cls.query.get(strategy_id)
        if strategy:
            strategy.active = not strategy.active
            db.session.commit()
            return strategy
        return None